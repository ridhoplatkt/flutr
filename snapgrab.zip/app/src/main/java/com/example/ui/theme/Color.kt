package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val NeonPurple = Color(0xFFA855F7)
val NeonIndigo = Color(0xFF6366F1)
val ElectricBlue = Color(0xFF06B6D4)
val CyanGlow = Color(0xFF38BDF8)
val DeepViolet = Color(0xFF7C3AED)

val BackgroundDark = Color(0xFF090614)
val BackgroundSurfaceDark = Color(0xFF120E22)
val SurfaceCard = Color(0xFF1A1530)
val SurfaceCardElevated = Color(0xFF231D3E)
val SurfaceCardLight = Color(0xFF2A234B)
val BorderSubtle = Color(0x33A855F7)
val BorderHighlight = Color(0x6638BDF8)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)

// Platform Brand Colors
val ColorYouTube = Color(0xFFFF0000)
val ColorInstagram = Color(0xFFE1306C)
val ColorTikTok = Color(0xFF00F2FE)
val ColorTwitter = Color(0xFF1DA1F2)
val ColorFacebook = Color(0xFF1877F2)
val ColorPinterest = Color(0xFFE60023)
val ColorSpotify = Color(0xFF1DB954)

// Gradient Brushes
val PurpleBlueGradient = Brush.horizontalGradient(
    colors = listOf(NeonPurple, NeonIndigo, ElectricBlue)
)

val CardGlowGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF231C42), Color(0xFF131733))
)

val BackgroundGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF090614), Color(0xFF0E0E22), Color(0xFF070B18))
)

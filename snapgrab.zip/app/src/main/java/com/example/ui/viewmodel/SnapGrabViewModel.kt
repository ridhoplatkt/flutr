package com.example.ui.viewmodel

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppSettings
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus
import com.example.data.model.VideoInfo
import com.example.data.repository.SnapGrabRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SnapGrabViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SnapGrabRepository(application)
    private val clipboardManager = application.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _analyzeError = MutableStateFlow<String?>(null)
    val analyzeError: StateFlow<String?> = _analyzeError.asStateFlow()

    private val _currentVideoInfo = MutableStateFlow<VideoInfo?>(null)
    val currentVideoInfo: StateFlow<VideoInfo?> = _currentVideoInfo.asStateFlow()

    private val _selectedQuality = MutableStateFlow("720p")
    val selectedQuality: StateFlow<String> = _selectedQuality.asStateFlow()

    private val _isAudioOnly = MutableStateFlow(false)
    val isAudioOnly: StateFlow<Boolean> = _isAudioOnly.asStateFlow()

    private val _historyFilter = MutableStateFlow("All")
    val historyFilter: StateFlow<String> = _historyFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    val settings: StateFlow<AppSettings> = repository.settingsFlow

    val allDownloads: StateFlow<List<DownloadItem>> = repository.getAllDownloads()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredDownloads: StateFlow<List<DownloadItem>> = combine(
        allDownloads,
        _historyFilter,
        _searchQuery
    ) { downloads, filter, query ->
        downloads.filter { item ->
            val matchesFilter = when (filter) {
                "Videos" -> !item.isAudioOnly
                "Audio" -> item.isAudioOnly
                "Completed" -> item.status == DownloadStatus.COMPLETED
                "Downloading" -> item.status == DownloadStatus.DOWNLOADING
                else -> true
            }

            val matchesQuery = query.isEmpty() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.platform.contains(query, ignoreCase = true) ||
                    item.author.contains(query, ignoreCase = true)

            matchesFilter && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDownloadsCount: StateFlow<Int> = allDownloads.combine(allDownloads) { list, _ ->
        list.count { it.status == DownloadStatus.DOWNLOADING }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun onUrlChanged(newUrl: String) {
        _urlInput.value = newUrl
        _analyzeError.value = null
    }

    fun pasteFromClipboard() {
        try {
            val clip = clipboardManager.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val text = clip.getItemAt(0).text?.toString()?.trim() ?: ""
                if (text.isNotEmpty()) {
                    _urlInput.value = text
                    _analyzeError.value = null
                    _toastMessage.value = "Link pasted from clipboard!"
                } else {
                    _toastMessage.value = "Clipboard is empty"
                }
            } else {
                _toastMessage.value = "Clipboard is empty"
            }
        } catch (e: Exception) {
            _toastMessage.value = "Could not access clipboard"
        }
    }

    fun loadSampleUrl(platform: String) {
        val sampleUrl = when (platform) {
            "Instagram" -> "https://www.instagram.com/reel/C3x9L8pvyZ1/"
            "YouTube" -> "https://youtu.be/dQw4w9WgXcQ"
            "TikTok" -> "https://www.tiktok.com/@creator/video/7289123456789"
            "Twitter" -> "https://x.com/techfeed/status/1762145890123"
            "Facebook" -> "https://fb.watch/qR7b2NkP/"
            "Pinterest" -> "https://pin.it/3xYz8kL"
            "Spotify" -> "https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT"
            else -> "https://youtu.be/sample"
        }
        _urlInput.value = sampleUrl
        _analyzeError.value = null
        analyzeUrl()
    }

    fun analyzeUrl() {
        val url = _urlInput.value.trim()
        if (url.isEmpty()) {
            _analyzeError.value = "Please enter or paste a valid link"
            return
        }

        viewModelScope.launch {
            _isAnalyzing.value = true
            _analyzeError.value = null
            _currentVideoInfo.value = null

            try {
                val info = repository.analyzeUrl(
                    url = url,
                    quality = _selectedQuality.value,
                    isAudioOnly = _isAudioOnly.value
                )
                _currentVideoInfo.value = info
                if (info.isAudioOnly) {
                    _isAudioOnly.value = true
                    _selectedQuality.value = "MP3 Audio"
                }
                _toastMessage.value = "Analysis complete for ${info.platform}!"
            } catch (e: Exception) {
                _analyzeError.value = e.message ?: "Failed to analyze link. Please check the URL."
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun selectQuality(quality: String) {
        _selectedQuality.value = quality
        val isAudio = quality.contains("MP3", ignoreCase = true) || quality.contains("Audio", ignoreCase = true)
        _isAudioOnly.value = isAudio
    }

    fun toggleAudioOnly(enabled: Boolean) {
        _isAudioOnly.value = enabled
        if (enabled) {
            _selectedQuality.value = "MP3 Audio"
        } else {
            _selectedQuality.value = "720p"
        }
    }

    fun startDownload() {
        val video = _currentVideoInfo.value ?: return

        viewModelScope.launch {
            try {
                repository.createAndStartDownload(
                    videoInfo = video,
                    chosenQuality = _selectedQuality.value,
                    isAudio = _isAudioOnly.value
                )
                _toastMessage.value = "Download started: ${video.title.take(24)}..."
            } catch (e: Exception) {
                _toastMessage.value = "Download failed to start: ${e.message}"
            }
        }
    }

    fun deleteDownload(item: DownloadItem) {
        viewModelScope.launch {
            repository.deleteDownload(item)
            _toastMessage.value = "Removed from history"
        }
    }

    fun cancelDownload(id: Long) {
        repository.cancelDownload(id)
        _toastMessage.value = "Download cancelled"
    }

    fun redownload(item: DownloadItem) {
        viewModelScope.launch {
            repository.redownload(item)
            _toastMessage.value = "Restarting download..."
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            _toastMessage.value = "All download history and cache cleared"
        }
    }

    fun setHistoryFilter(filter: String) {
        _historyFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun updateSettings(newSettings: AppSettings) {
        repository.updateSettings(newSettings)
        _toastMessage.value = "Settings saved"
    }

    fun getCacheSizeFormatted(): String {
        val bytes = repository.getCacheSizeBytes()
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
            bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
            bytes >= 1024 -> String.format("%.1f KB", bytes / 1024.0)
            else -> "$bytes B"
        }
    }
}

package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val originalUrl: String,
    val title: String,
    val author: String = "",
    val platform: String,
    val quality: String,
    val thumbnail: String,
    val localFilePath: String? = null,
    val downloadUrl: String,
    val progress: Int = 0,
    val status: String = DownloadStatus.PENDING.name,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val duration: Long = 0L,
    val isAudioOnly: Boolean = false,
    val errorMessage: String? = null
) {
    fun toDownloadItem(): DownloadItem {
        return DownloadItem(
            id = id,
            originalUrl = originalUrl,
            title = title,
            author = author,
            platform = platform,
            quality = quality,
            thumbnail = thumbnail,
            localFilePath = localFilePath,
            downloadUrl = downloadUrl,
            progress = progress,
            status = try { DownloadStatus.valueOf(status) } catch (e: Exception) { DownloadStatus.COMPLETED },
            downloadedBytes = downloadedBytes,
            totalBytes = totalBytes,
            timestamp = timestamp,
            duration = duration,
            isAudioOnly = isAudioOnly,
            errorMessage = errorMessage
        )
    }

    companion object {
        fun fromDownloadItem(item: DownloadItem): DownloadEntity {
            return DownloadEntity(
                id = item.id,
                originalUrl = item.originalUrl,
                title = item.title,
                author = item.author,
                platform = item.platform,
                quality = item.quality,
                thumbnail = item.thumbnail,
                localFilePath = item.localFilePath,
                downloadUrl = item.downloadUrl,
                progress = item.progress,
                status = item.status.name,
                downloadedBytes = item.downloadedBytes,
                totalBytes = item.totalBytes,
                timestamp = item.timestamp,
                duration = item.duration,
                isAudioOnly = item.isAudioOnly,
                errorMessage = item.errorMessage
            )
        }
    }
}

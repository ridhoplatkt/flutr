package com.example.data.repository

import android.content.Context
import com.example.data.api.CobaltApiService
import com.example.data.api.DownloadService
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.data.local.SnapGrabDatabase
import com.example.data.model.AppSettings
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus
import com.example.data.model.VideoInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.io.File

class SnapGrabRepository(
    private val context: Context,
    private val downloadDao: DownloadDao = SnapGrabDatabase.getDatabase(context).downloadDao(),
    private val apiService: CobaltApiService = CobaltApiService(),
    private val downloadService: DownloadService = DownloadService(context, downloadDao)
) {
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _settingsFlow = MutableStateFlow(AppSettings())
    val settingsFlow = _settingsFlow.asStateFlow()

    suspend fun analyzeUrl(url: String, quality: String = "720", isAudioOnly: Boolean = false): VideoInfo {
        return apiService.analyze(url, quality, isAudioOnly)
    }

    fun getAllDownloads(): Flow<List<DownloadItem>> {
        return downloadDao.getAllDownloads().map { list ->
            list.map { it.toDownloadItem() }
        }
    }

    fun getDownloadsByPlatform(platform: String): Flow<List<DownloadItem>> {
        return downloadDao.getDownloadsByPlatform(platform).map { list ->
            list.map { it.toDownloadItem() }
        }
    }

    suspend fun createAndStartDownload(videoInfo: VideoInfo, chosenQuality: String, isAudio: Boolean): Long {
        val entity = DownloadEntity(
            originalUrl = videoInfo.originalUrl,
            title = videoInfo.title,
            author = videoInfo.author,
            platform = videoInfo.platform,
            quality = chosenQuality,
            thumbnail = videoInfo.thumbnail,
            downloadUrl = videoInfo.downloadUrl,
            progress = 0,
            status = DownloadStatus.DOWNLOADING.name,
            totalBytes = videoInfo.fileSizeEstimate,
            duration = videoInfo.duration,
            isAudioOnly = isAudio
        )

        val newId = downloadDao.insertDownload(entity)
        val downloadItem = entity.copy(id = newId).toDownloadItem()

        // Launch download asynchronously
        scope.launch {
            downloadService.startDownload(downloadItem)
        }

        return newId
    }

    suspend fun deleteDownload(item: DownloadItem) {
        // Delete local file if exists
        item.localFilePath?.let { path ->
            try {
                val f = File(path)
                if (f.exists()) f.delete()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        downloadDao.deleteDownloadById(item.id)
    }

    suspend fun clearAllHistory() {
        downloadDao.clearAll()
        // clear download cache folder
        try {
            val targetDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "SnapGrab")
            if (targetDir.exists()) {
                targetDir.deleteRecursively()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelDownload(downloadId: Long) {
        downloadService.cancelDownload(downloadId)
    }

    suspend fun redownload(item: DownloadItem) {
        val updated = item.copy(status = DownloadStatus.DOWNLOADING, progress = 0)
        downloadDao.updateProgress(item.id, 0, 0, item.totalBytes, DownloadStatus.DOWNLOADING.name)
        scope.launch {
            downloadService.startDownload(updated)
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        _settingsFlow.value = newSettings
    }

    fun getCacheSizeBytes(): Long {
        return try {
            val targetDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "SnapGrab")
            if (targetDir.exists()) {
                targetDir.walkTopDown().filter { it.isFile }.map { it.length() }.sum()
            } else 0L
        } catch (e: Exception) {
            0L
        }
    }
}
